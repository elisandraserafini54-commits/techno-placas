# Traduz Ar-Condicionado — versão inicial 0.1

Aplicação web responsiva/PWA para consulta de códigos e indicadores de ar-condicionado.

## O que funciona nesta versão
- Busca por marca e código.
- Campo opcional para o modelo do equipamento.
- Fichas iniciais de indicadores Samsung CF, dF, dL, AP e C1, com fonte oficial.
- Busca complementar na web quando o código ainda não está no banco.
- Manifesto e service worker para instalação como aplicativo web em navegador compatível.

## Limitações importantes
- A lista de marcas prepara a interface, mas ainda não significa que o banco contenha códigos validados de todas elas.
- Os códigos variam conforme modelo e série. Não use uma ficha sem conferir a documentação oficial correspondente.
- Esta versão não usa uma API de fabricante nem tem banco de dados remoto. A pesquisa web é aberta no navegador; o banco inicial está no arquivo `index.html`.
- Para atualizações online centralizadas e colaboração de técnicos, a próxima etapa será ligar a interface a um banco de dados hospedado.

## Publicar gratuitamente para testar
1. Crie um repositório público no GitHub pelo navegador do celular.
2. Envie os três arquivos `index.html`, `manifest.json` e `sw.js` para a raiz do repositório.
3. Nas configurações do repositório, abra **Pages**, escolha **Deploy from a branch**, selecione `main` e `/ (root)` e salve.
4. Aguarde a URL publicada em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.
5. Abra a URL no Chrome Android. Use o menu ⋮ e procure **Adicionar à tela inicial** ou **Instalar app**.

## APK
Para empacotar como Android usando PWABuilder, primeiro publique a PWA com HTTPS. Depois acesse https://www.pwabuilder.com/ e informe a URL publicada. A geração do pacote Android e a instalação local devem ser testadas antes de distribuir. Para publicar na Play Store, há requisitos adicionais e taxa de cadastro de desenvolvedor.
